# JSON Viewer

![JSON Viewer](./json_viewer.png)

Python3 script to view a JSON file as a tree in GUI.

Invoke as:

```
$ ./json_viewer.py sample.json
```
